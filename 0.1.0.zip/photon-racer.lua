VERSION = "0.1.0"

AddRuntimeFile("photon-racer", "colorscheme", "photon-racer.micro")
